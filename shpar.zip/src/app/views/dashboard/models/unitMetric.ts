export class UnitMetric {
    id: Number;
    unitType:string;
    code:string;
    type:string;
    name:string;
    value:string;
    colorCode:string;
}