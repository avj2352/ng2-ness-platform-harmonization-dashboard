export interface ManageHierarchy {
    id:number;
    name:string;
    code:string;
    hierarchy:number;
};