export class UserLoginCreditional {
    public email:string;
    public password:string;
    constructor () {
        this.email = '';
        this.password = '';
    }
}//end:UserLoginCreditional