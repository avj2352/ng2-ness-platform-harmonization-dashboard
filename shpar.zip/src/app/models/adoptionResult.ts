export class AdoptionResult {
    public reportId:number;
    public productId:number;
    public assetId:number;
    public unitTypeId:number;
    public unitId:number;
    public unitValue:string;
    constructor() {
        
    }

}//end:AdoptionResult