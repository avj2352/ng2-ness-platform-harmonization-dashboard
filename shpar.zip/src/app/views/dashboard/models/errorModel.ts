export class ErrorModel {
    title:string;
    content:string;
    button1:string;
    button2 :string;
    constructor() {
        this.title = '';
        this.content ='';
        this.button1 = '';
        this.button2 = '';
    }
}