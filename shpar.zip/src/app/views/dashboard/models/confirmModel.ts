export class ConfirmModel {
    title:string;
    content:string;
    type:string;
    constructor() {
        this.title = '';
        this.content ='';
        this.type ='';
    }
}