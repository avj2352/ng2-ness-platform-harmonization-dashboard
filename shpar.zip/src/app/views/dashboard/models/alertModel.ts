export class AlertModel {
    title:string;
    content:string;
    constructor() {
        this.title = '';
        this.content ='';
    }
}