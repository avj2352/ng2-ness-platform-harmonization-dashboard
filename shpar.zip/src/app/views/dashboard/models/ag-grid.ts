export class AgGrid {
    colDefs:Array<any>;
    rowData:any;
    singleClickEdit:boolean;
    groupHeaderHeight:number;
    angularCompileRows:boolean;
    headerHeight:number;
    frameworkComponents:any;
}